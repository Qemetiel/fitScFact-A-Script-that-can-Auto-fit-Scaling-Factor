#!/bin/bash
# Powered by Voidmio
# 04/18/25

trainingSet=ZPVE15_10
# trainingSet=Z1

level="$1"
cd ./sets/${trainingSet}
echo Waiting....

for inp in *.gjf
do
	sed -i "4c\\${level}" "${inp}"
	g16 < ${inp} > ${inp//gjf/out} &
done

wait

echo ${level} > ZPE.txt

for inp in *.gjf
do
    	zpe1=$(grep "(Kcal/Mol)" "${inp//gjf/out}" | tail -n1 | awk '{print $1}' | head -n1)
    	zpe2=$(grep -oP 'ZPE=\K\d+\.\d+' "${inp}" | head -n1)
	echo ${zpe1} ${zpe2} >> ZPE.txt
	rm -rf ${inp//gjf/out}
done

sclZPE=$(awk '
BEGIN { sum_xy = 0; sum_x2 = 0 }
{
  if (NF == 2) { 
    x = $1; y = $2
    sum_xy += x * y
    sum_x2 += x * x
  }
}
END {
  if (sum_x2 > 0) {
    k = sum_xy / sum_x2
    printf "sclZPE = %.6f\n", k
  } else {
    print "ERROR!"
  }
}' ZPE.txt)

echo Used Data Set: ${trainingSet}
echo Level: ${level}
echo ${sclZPE}
echo ${sclZPE} >> ZPE.txt
mv ./ZPE.txt ../../${trainingSet}_ZPE.txt

echo Congratulations! Love from Voidmio.
